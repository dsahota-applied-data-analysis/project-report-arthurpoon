import os
DATA_DIR = os.path.dirname(os.path.realpath(__file__))
EXPERIMENTS_RUNS_DIR = os.path.join(DATA_DIR, 'experiments_runs')
VECTORS_DIR = os.path.join(DATA_DIR, 'vectors')
