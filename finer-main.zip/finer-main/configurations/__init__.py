import os
CONFIG_DIR = os.path.dirname(os.path.realpath(__file__))
from configurations.configuration import Configuration
